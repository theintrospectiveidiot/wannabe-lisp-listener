#!/bin/bash

[ ! -f "Fonts/Terminus.ttf" ] && mkdir Fonts/ && mv *.ttf Fonts/

[ ! -x "something_new_s" ] && chmod +x ./something_new_s

echo "Enjoy using the objectively best editor of all time!!"

./something_new_s


